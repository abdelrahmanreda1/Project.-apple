/* 
let main = document.getElementById('main')

let gold = document.getElementById('gold');

let skyblue=document.getElementById('skyblue');

let gray = document.getElementById('gray');

let beige = document.getElementById('beige');

let red = document.getElementById('red');
let body =document.body 

gold.onclick= function()
{
  body.style.background='#d4af37'
  main.src=this.src
}

skyblue.onclick= function()
{
  body.style.background=''
  main.src=this.src
}

gray.onclick= function()
{
  body.style.background=''
  main.src=this.src
}

beige.onclick= function()
{
  body.style.background=''
  main.src=this.src
}

red.onclick= function()
{
  body.style.background='#ff0000'
  main.src=this.src
}*/